# txt_adjuster

* Step 1: After the user selects a picture, click the Apply button and then go to step 2;

* Step 2: The user selects the text block with the left mouse button, clicks Apply to enter step 3, and clicks the Go Back button to return to step 1;

* Step 3: After the user enters the text, select the desired font and font size and click the Apply button. The program will try to place the text in the specified block. The user can click the Go Back button to return to step 2, and the user can also click the Save button to save The picture containing the text is saved as a png format file. In addition, a selection button is provided, and the user can choose whether to display the text box.